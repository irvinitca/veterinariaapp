<?php return array (
  'select-anidado' => 'App\\Http\\Livewire\\SelectAnidado',
);