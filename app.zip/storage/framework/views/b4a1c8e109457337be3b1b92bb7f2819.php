<!DOCTYPE html>
<html>
<head>
    <title>Reportes de Ingresos Mensuales</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body style="background-image: ">
    <style>
 body {
            background-color: #cefcce;
            background-repeat: no-repeat;
            background-position: top right;
            background-size: cover;
        }

.iconbtn{
	max-height: 30px!important;
    width: 30px!important;
    padding: 1px!important;
}

h2{
    text-align: center;
    font-size: 18px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: white;
    padding: 30px 0;
}

/* Table Styles */

.table-wrapper{
    margin: 10px 70px 70px;
    box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
}

.fl-table {
    border-radius: 5px;
    font-size: 12px;
    font-weight: normal;
    border: none;
    border-collapse: collapse;
    width: 100%;
    max-width: 100%;
    white-space: nowrap;
    background-color: white;
}

.fl-table td, .fl-table th {
    text-align: center;
    padding: 8px;
}

.fl-table td {
    border-right: 1px solid #f8f8f8;
    font-size: 12px;
}

.fl-table thead th {
    color: #ffffff;
    background: #4FC3A1;
}


.fl-table thead th:nth-child(odd) {
    color: #ffffff;
    background: #324960;
}

.fl-table tr:nth-child(even) {
    background: #F8F8F8;
}
h4{
    color:#324960;
}
p{
    color: #36866e;
    font-size: 20px;
}
span{
    color: rgb(167, 41, 41);
    font-weight: bold;
    font-size: 20px;
}

    </style>

    <h4>
        <img class="logovet" src="<?php echo e(public_path('logo/cio-logo.png')); ?>" alt="Logo de CIO" style="width: 80px; height:80px">
        <label style="margin-top:-5rem">Veterinaria CIO</label>
    </h4>
    <div style="position: absolute; top: 10px; right: 20px;">
        <img src="<?php echo e(public_path('img/reporte-ingresos.png')); ?>" alt="Imagen" style="width: 125px; height: 125px;">
    </div>
    <h4 class="text-center"><?php echo e($title); ?></h4><br>
    <p>Correpondientes al mes de <span> <?php echo e($monthName); ?> </span>del año<span> <?php echo e($year); ?></span> <br>
        Tipo de Citas: <span> <?php echo e($type); ?></span> <br>
        **INGRESO TOTAL DE <?php echo e($monthName); ?>: <span>$<?php echo e($total); ?> dólares</span></p>

    <table class="fl-table">
        <thead>
        <tr>
            <th># CITA</th>
            <th>FECHA</th>
            <th>MASCOTA</th>
            <th>TIPO DE CITA</th>
            <th>Monto</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($appointment->id); ?></td>
            <td><?php echo e($appointment->date_start); ?></td>
            <td><?php echo e($appointment->pet->name); ?>   </td>
            <td><?php echo e($appointment->type); ?></td>
            <td>
                <?php if($appointment->total): ?>
                    <?php echo e($appointment->total); ?>

                <?php else: ?>
                    Sin cancelar
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\Users\Irvin\Documents\AFE\veterinariaapp\resources\views/admin/reporteIngresosMes.blade.php ENDPATH**/ ?>