<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <head>
        <!-- Vincular el archivo CSS -->
        <link href="<?php echo e(asset('css/formcita.css')); ?>" rel="stylesheet">

    </head>
    <div class="container">
   
    <div class="signup-container">
        <div class="left-container">
          <h1>
            <img class="logovet" src="<?php echo e(asset('logo/cio-logo.png')); ?>" alt="Logo de CIO">
            VeterinariaCIO
          </h1>
          <div class="puppy">
            <img  class="reportepng" src="/img/reportes.png"/>
          </div>
        </div>
        <div class="right-container">
          <header>
            <h1>Creacion De Reportes de Pacientes por Doctor </h1>
            </header>
            <div class="formdiv">
              <form action="<?php echo e(route('admin.generate-pdf-pat')); ?>" method="POST">
                <?php echo csrf_field(); ?>





                <div class="form-group">
                    <label for="date_start">Desde:</label>
                    <input type="datetime-local" name="date_start" id="date_start" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="date_start">Hasta:</label>
                    <input type="datetime-local" name="date_end" id="date_end" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="user_id">Veterinario:</label>
                    <select name="user_id" id="user_id" class="form-control select2" required>
                        <option value="">Sin asignar</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <div class="setfooter">
                <button id="back" type="button">Cancelar</button>
                <button id="next" type="submit" class="btn btn-secondary">Generar</button>
              </div>
            </form>
            </div>
            <script>
                document.getElementById("back").addEventListener("click", function() {
                    window.location.href = "/dashboard";
                });
            </script>



        </div>
      </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>


<script>
    $(document).ready(function () {
        $('.select2').select2({ width: '100%'});

    });
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Irvin\Documents\AFE\veterinariaapp\resources\views/admin/formReportePacientesVeterinario.blade.php ENDPATH**/ ?>