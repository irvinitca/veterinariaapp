<a href="/">
    <img src="{{ asset('logo/cio-logo.png') }}" width="60px">
 </a>

