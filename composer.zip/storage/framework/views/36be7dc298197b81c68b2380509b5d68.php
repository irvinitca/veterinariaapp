<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <head>
        <!-- Vincular el archivo CSS -->
        <link href="<?php echo e(asset('css/formcita.css')); ?>" rel="stylesheet">
    </head>
    <div class="container">
    <div class="signup-container">
        <div class="left-container">
            <img class="logovet" src="<?php echo e(asset('logo/cio-logo.png')); ?>" alt="Logo de CIO">
          <div class="puppy">
            <h1></h1>
            <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/38816/image-from-rawpixel-id-542207-jpeg.png"/>
            </h1>
        </div>
        </div>
        <div class="right-container">
          <header>
            <h1>Crear Nueva Mascota</h1>
            </header>

            <div class="formdiv">
                <form wire:submit.prevent="submit" action="<?php echo e(route('pets.store')); ?>" method="POST" onsubmit="return confirmarGuardar(event)">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Nombre:</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-paw"></i></span>
                            </div>
                            <input name="name" id="name" autocomplete="off" class="form-control" rows="3" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="weight">Peso</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-weight"></i></span>
                            </div>
                            <input name="weight" type="number" placeholder="libras" id="weight"  class="form-control" rows="3" required>
                        </div>
                    </div>

                    <!--Componentes selects Livewire -->
                    <div>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-anidado')->html();
} elseif ($_instance->childHasBeenRendered('KsRLZJj')) {
    $componentId = $_instance->getRenderedChildComponentId('KsRLZJj');
    $componentTag = $_instance->getRenderedChildComponentTagName('KsRLZJj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KsRLZJj');
} else {
    $response = \Livewire\Livewire::mount('select-anidado');
    $html = $response->html();
    $_instance->logRenderedChild('KsRLZJj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>

                    <div class="form-group">
                        <label for="age">Edad</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-calendar-day"></i></span>
                            </div>
                            <input name="age" type="number" placeholder="ej.: 3" id="age"  class="form-control" rows="3" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="owner_id">Dueño o Encargado:</label>
                        <select name="owner_id" id="owner_id" class="form-control select2">
                            <option value="" disabled selected>Seleccione</option>
                            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($owner->id); ?>"><?php echo e($owner->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                    <div class="setfooter">
                        <button id="back" type="button">Cancelar</button>
                        <button id="next" type="submit"  class="btn">Guardar</button>
                    </div>
                </form>
            </div>

            <script>
                // Escuchar el evento 'selectsSubmitted' emitido por el componente 'SelectAnidado'
                Livewire.on('selectsSubmitted', data => {
                    // Aquí puedes manejar los datos seleccionados
                    // Por ejemplo, puedes asignar los valores a campos ocultos en el formulario
                    document.getElementById('selectedType').value = data.type;
                    document.getElementById('selectedBreed').value = data.breed;
                });
                Livewire.on('submitForm', () => {
                    //console.log('Form submitted');
                    // Submit el formulario
                    document.getElementById('form-pets-nuevos').submit();
                });
            </script>

            <script>
                function confirmarGuardar(event) {
                    if (!confirm('¿Estás seguro de que deseas crear esta mascota?')) {
                        event.preventDefault();
                        return false;
                    }
                    return true;
                }
            </script>
            <script>
                document.getElementById("back").addEventListener("click", function() {
                    window.location.href = "<?php echo e(route('pet.dashboard')); ?>";
                });
            </script>
        </div>
      </div>
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
  <?php endif; ?>
</div>


<script>
    $(document).ready(function () {
        $('.select2').select2({ width: '100%' });

    });
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Irvin\Documents\AFE\veterinariaapp\resources\views/pet/pets-nuevos.blade.php ENDPATH**/ ?>