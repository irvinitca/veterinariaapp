<a href="/">
    <img src="<?php echo e(asset('logo/cio-logo.png')); ?>" width="60px">
 </a>

<?php /**PATH C:\Users\Irvin\Documents\AFE\veterinariaapp\resources\views/components/application-mark.blade.php ENDPATH**/ ?>