<div>
    <div>
        <div class="form-group">
            <label for="type">Tipo:</label>
            <select wire:model="selectedType" name="selectedType" id="selectedType" class="form-control">
                <option value="">Selecciona el tipo</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
<?php if(!is_null($breeds)): ?>
    <div>
        <div class="form-group">
            <label for="breed">Razas:</label>
            <select wire:model="selectedBreed" name="selectedBreed" id="selectedBreed" class="form-control ">
                <option value="">Selecciona la raza</option>
                <?php $__currentLoopData = $breeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($breed->id); ?>"><?php echo e($breed->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\Users\Irvin\Documents\AFE\veterinariaapp\resources\views/livewire/select-anidado.blade.php ENDPATH**/ ?>